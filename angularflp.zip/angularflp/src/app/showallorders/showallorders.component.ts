import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-showallorders',
  templateUrl: './showallorders.component.html',
  styleUrls: ['./showallorders.component.css']
})
export class ShowallordersComponent implements OnInit {
  result: any
  submitted = false;
  constructor(private service: LoginService) { }

  ngOnInit() {
    this.showorder()
  }
  showorder(): void {
    this.service.vieworders().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
  }
  delete(order_id) {
    console.log(order_id)
    this.service.deleteOrder(order_id).subscribe(data => {
      this.result = data;
      alert(this.result)
      window.location.reload();
    });

  }

}
